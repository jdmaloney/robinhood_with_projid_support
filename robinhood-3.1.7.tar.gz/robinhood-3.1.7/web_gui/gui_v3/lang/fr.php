<?php
/*
 * Copyright (C) 2016 CEA/DAM
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the CeCILL License.
 *
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license (http://www.cecill.info) and that you
 * accept its terms.
 */


$lang['uid'] = "Proprietaire";
$lang['gid'] = "Groupe";
$lang['lhsm_status'] = "Status LHSM";
$lang['checksum_status'] = "Status Checksum";

?>
