<?php
/*
 * Copyright (C) 2016 CEA/DAM
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the CeCILL License.
 *
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license (http://www.cecill.info) and that you
 * accept its terms.
 */


$lang = array();

$lang['sz0'] = "Empty";
$lang['sz1'] = "1B-32B";
$lang['sz32'] = "32B-1KB";
$lang['sz1K'] = "1KB-32KB";
$lang['sz32K'] = "32KB-1MB";
$lang['sz1M'] = "1MB-32MB";
$lang['sz32M'] = "32MB-1GB";
$lang['sz1G'] = "1GB-32GB";
$lang['sz32G'] = "32GB-1TB";
$lang['sz1T'] = "1TB+";
?>
